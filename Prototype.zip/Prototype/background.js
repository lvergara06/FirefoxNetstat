
/*
This is the page for which we want to rewrite the User-Agent header.
*/
let targetPage = "https://www.prismluxe.art/";

// Add a context menu action on every image element in the page.
browser.contextMenus.create({
  id: "info-send",
  title: "Send '%s'",
  contexts: ["selection"]
});

// Manage pending collected images.
let pendingHeaders = [];
browser.runtime.onMessage.addListener((msg) => {
    if (msg.type === "get-pending-hdrs") {
      let hdrs = pendingHeaders;
      pendingHeaders = [];
    return Promise.resolve(hdrs);
  }
});

// Handle the context menu action click events.
browser.contextMenus.onClicked.addListener(async (info) => {
  try {
      if (info.menuItemId === "info-send") {
          console.log(info.selectionText);
      }
    } catch (err) {
    console.error(err);
  }
});

// This function opens a dialog box, if yes is selected then headers are logged
// It blocks until the selection is made
function sendHeaderInfo(e) {
    console.log("Entrace");

    // Save headers to send to other script
    try {
        for (let header of e.requestHeaders) {
            pendingHeaders.push(header);
            //console.log(header.name);
            //console.log(header.value);
        }
    } catch (err) {
        console.log("pusing headers failed");
        console.error(err);
    }

    // Call pop up and wait for answer
    try {
        browser.windows.create({
          type: "popup", url: "/popup.html",
          top: 0, left: 0, width: 250, height: 150,
        });
    } catch (err) {
        console.log("Creating popup failed");
        console.error(err);
      }

      return { requestHeaders: e.requestHeaders };
}

browser.webRequest.onBeforeSendHeaders.addListener(sendHeaderInfo,
    { urls: [targetPage] },
    ["blocking", "requestHeaders"]);
