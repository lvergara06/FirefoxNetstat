/* global saveCollectedBlobs, uuidv4, preventWindowDragAndDrop */

"use strict";

class Popup {
    constructor(containerEl) {
        this.containerEl = containerEl;

        this.state = {
            headers: [],
            lastMessage: undefined,
        };

        this.onClickYes = this.onClickYes.bind(this);
        this.onClickNo = this.onClickNo.bind(this);

        this.containerEl.querySelector("button.answer-yes").onclick = this.onClickYes;
        this.containerEl.querySelector("button.answer-no").onclick = this.onClickNo;
    }

    setState(state) {
        // Merge the new state on top of the previous one and re-render everything.
        this.state = Object.assign(this.state, state);
        this.render();
    }

    onClickYes() {
        setTimeout(() => {
            this.setState({ lastMessage: { text: "yes", type: "success" } });
        }, 20);

        // Send out the headers to the console
        for (const hdr of this.state.headers) {
            console.log(hdr.name);
            console.log(hdr.value);
        }

        var request = new XMLHttpRequest();
        request.open("POST", "https://www.googleapis.com/urlshortener/v1/url");
        request.setRequestHeader("Content-Type", "application/json");
        request.overrideMimeType("text/plain");
        request.onload = function () {
            alert("Response received: " + request.responseText);
        };
        request.send('{"longUrl": "http://www.google.com/"}');

        return;
    }

    onClickNo() {
        setTimeout(() => {
            this.setState({ lastMessage: { text: "no", type: "success" } });
        }, 20);

        return;
    }

    render() {
        const { headers, lastMessage } = this.state;
        if (lastMessage) {
            getCurrentWindow().then((currentWindow) => {
                browser.windows.remove(currentWindow.id);
            });
        }
    }
}

const popup = new Popup(document.getElementById('app'));

preventWindowDragAndDrop();

//browser.runtime.onMessage.addListener(async (msg) => {
//  if (msg.type === "new-collected-images") {
//    let collectedBlobs = popup.state.collectedBlobs || [];
//    const fetchRes = await fetchBlobFromUrl(msg.url);
//    collectedBlobs.push(fetchRes);
//    popup.setState({collectedBlobs});
//    return true;
//  }
//});

browser.runtime.sendMessage({ type: "get-pending-hdrs" }).then(async res => {

    let headers = popup.state.headers || [];
    for (const hdr of res) {
        headers.push(hdr);
        popup.setState({ headers });
    }
});

function getCurrentWindow() {
    return browser.windows.getCurrent();
}